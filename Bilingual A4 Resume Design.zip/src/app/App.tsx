import React, { useState } from 'react';
import { Resume } from './components/resume';
import { ATSResume } from './components/ats-resume';
import { Layout, FileText, Settings, Download, Eye } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'main' | 'ats' | 'styleguide'>('main');
  const [language, setLanguage] = useState<'en' | 'pt'>('en');

  return (
    <div className="min-h-screen bg-[#F0F2F5] pb-20">
      {/* Navigation / Toolbar */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#0B3D91] rounded flex items-center justify-center text-white font-bold">H</div>
          <div>
            <h1 className="text-sm font-bold text-gray-900 leading-none">Heitor Penha - Resume Project</h1>
            <p className="text-[10px] text-gray-500 font-medium mt-1">Billing / Finance Analyst (Junior → Semi-Senior)</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
            <button 
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${language === 'en' ? 'bg-[#0B3D91] text-white shadow-sm' : 'text-gray-500'}`}
            >
              EN
            </button>
            <button 
              onClick={() => setLanguage('pt')}
              className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${language === 'pt' ? 'bg-[#0B3D91] text-white shadow-sm' : 'text-gray-500'}`}
            >
              PT
            </button>
          </div>

          <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg">
            <button 
              onClick={() => setActiveTab('main')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-xs font-semibold transition-all ${activeTab === 'main' ? 'bg-white text-[#0B3D91] shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Layout size={14} /> Main Design (A4)
            </button>
            <button 
              onClick={() => setActiveTab('ats')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-xs font-semibold transition-all ${activeTab === 'ats' ? 'bg-white text-[#0B3D91] shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <FileText size={14} /> ATS Version
            </button>
            <button 
              onClick={() => setActiveTab('styleguide')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-xs font-semibold transition-all ${activeTab === 'styleguide' ? 'bg-white text-[#0B3D91] shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Settings size={14} /> Style Guide
            </button>
          </div>

          <button 
            onClick={() => window.print()}
            className="flex items-center gap-2 px-4 py-2 bg-[#0B3D91] text-white rounded-lg text-xs font-bold hover:bg-[#093278] transition-colors"
          >
            <Download size={14} /> Export PDF
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="container mx-auto mt-8 flex justify-center px-4">
        {activeTab === 'main' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="mb-4 flex items-center justify-between text-gray-500 text-[10px] font-bold uppercase tracking-widest px-2">
              <span>A4 Print Layout / 210mm x 297mm</span>
              <span className="flex items-center gap-1"><Eye size={12} /> Design Preview</span>
            </div>
            <Resume language={language} />
          </div>
        )}

        {activeTab === 'ats' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <ATSResume language={language} />
          </div>
        )}

        {activeTab === 'styleguide' && (
          <div className="w-full max-w-4xl bg-white p-12 rounded-xl shadow-lg animate-in zoom-in-95 duration-300">
            <h2 className="text-2xl font-bold text-[#0B3D91] mb-8 flex items-center gap-2">
              <Settings className="text-[#6CA0DC]" /> Design Tokens & Guidelines
            </h2>
            
            <div className="grid grid-cols-2 gap-12">
              <section>
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Color Palette</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="h-16 rounded-lg bg-[#0B3D91] shadow-inner"></div>
                    <p className="text-[10px] font-bold">Primary Navy</p>
                    <p className="text-[10px] text-gray-400">#0B3D91</p>
                  </div>
                  <div className="space-y-2">
                    <div className="h-16 rounded-lg bg-[#6CA0DC] shadow-inner"></div>
                    <p className="text-[10px] font-bold">Accent Light Blue</p>
                    <p className="text-[10px] text-gray-400">#6CA0DC</p>
                  </div>
                  <div className="space-y-2">
                    <div className="h-16 rounded-lg bg-[#2F4F4F] shadow-inner border border-gray-100"></div>
                    <p className="text-[10px] font-bold">Dark Gray (Text)</p>
                    <p className="text-[10px] text-gray-400">#2F4F4F</p>
                  </div>
                  <div className="space-y-2">
                    <div className="h-16 rounded-lg bg-[#F7F9FB] shadow-inner border border-gray-100"></div>
                    <p className="text-[10px] font-bold">Off-White (Sidebars)</p>
                    <p className="text-[10px] text-gray-400">#F7F9FB</p>
                  </div>
                </div>
              </section>

              <section className="space-y-8">
                <div>
                  <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Typography</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-[21px] font-bold text-[#0B3D91]">Heitor Penha</p>
                      <p className="text-[10px] text-gray-400">Headline: Inter Bold, 16pt / 21px</p>
                    </div>
                    <div>
                      <p className="text-[14px] font-semibold uppercase tracking-wider text-[#0B3D91]">Professional Experience</p>
                      <p className="text-[10px] text-gray-400">Section Header: Inter Semi-Bold, 11pt / 14px</p>
                    </div>
                    <div>
                      <p className="text-[10.5px] text-gray-700">Financial Analyst, North America — Montreal, Canada</p>
                      <p className="text-[10px] text-gray-400">Body Text: Inter Regular, 10pt / 10.5px</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Export Settings</h3>
                  <ul className="text-[11px] text-gray-600 space-y-2 list-disc pl-4">
                    <li>Format: A4 (210mm x 297mm)</li>
                    <li>Resolution: 300 DPI (for print)</li>
                    <li>Fonts: Inter (embedded)</li>
                    <li>Bleed: 3mm recommended</li>
                  </ul>
                </div>
              </section>
            </div>

            <div className="mt-12 pt-8 border-t border-gray-100">
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Layout Grid</h3>
              <div className="bg-gray-50 h-32 rounded-lg flex items-center justify-center border border-dashed border-gray-300">
                <p className="text-[10px] text-gray-400 italic">8px - 12px Baseline Grid System / 24px - 28px Section Spacing</p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Floating Instructions for the user */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-md border border-gray-200 shadow-xl px-6 py-3 rounded-full flex items-center gap-6">
        <p className="text-[11px] font-medium text-gray-600 flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
          Press <kbd className="bg-gray-100 px-1.5 py-0.5 rounded border border-gray-300 text-[10px]">Ctrl + P</kbd> to export the active resume as PDF.
        </p>
      </div>

      <style>{`
        @media print {
          body { background: white !important; }
          nav, .fixed { display: none !important; }
          main { margin-top: 0 !important; padding: 0 !important; }
          .container { max-width: none !important; width: 100% !important; }
          button { display: none !important; }
          .animate-in { animation: none !important; }
          @page {
            size: A4;
            margin: 0;
          }
        }
      `}</style>
    </div>
  );
};

export default App;
